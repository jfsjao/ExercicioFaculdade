-Poucas fotos do local na internet então usei fotos de parques genericas.

site que foi hospedado: 
https://br.000webhost.com

HortoDeSaoCarlos

&x7w7cmYcz*1E%Nmgtrk

site:

https://hortodesaocarlos.000webhostapp.com/HTML/Homepage.html


Algumas informações foram tiradas nesses sites:
https://praturista.com/horto-florestal-de-sao-carlos-sp/#
http://hortopreservado.blogspot.com/p/outros-hortos.html
http://www.saocarlos.sp.gov.br/index.php/noticias-2007/149839-horto-municipal.html