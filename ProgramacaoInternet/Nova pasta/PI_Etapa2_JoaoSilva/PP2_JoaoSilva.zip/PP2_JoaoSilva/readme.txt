-Poucas fotos do local na internet então usei fotos de parques genericas.

site que foi hospedado: 
https://br.000webhost.com

HortomunicipalDeSaoCarlos

OljTmJ3f3H(vGCIp*18W

site: *tive que tirar a primeira etapa do ar, por conta de interferencia*

https://hortomunicipaldesaocarlos.000webhostapp.com


Algumas informações foram tiradas nesses sites:
https://praturista.com/horto-florestal-de-sao-carlos-sp/#
http://hortopreservado.blogspot.com/p/outros-hortos.html
http://www.saocarlos.sp.gov.br/index.php/noticias-2007/149839-horto-municipal.html