var lista = ['João Felipe','2025','Inglês']; ['Pedro','2026', 'Inglês'] ['Ricardo','2027','Mandarim']
document.write()